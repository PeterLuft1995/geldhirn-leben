"use strict";
/* brand.config.js – zentrale Markenkonfiguration LebensRadar. */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.BRAND_CONFIG = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  return {
    siteId: "lebensradar",
    name: "Geldhirn Leben",
    claim: "Reisen, Familie und Tiere – ehrlich eingeordnet.",
    tagline: "Magazin fuer Reisen, Familie, Tiere und Freizeit – mit echten Kosten statt Werbeversprechen.",
    domain: "https://leben.geldhirn.de",
    themeColor: "#1E9E6B",
    backgroundColor: "#FBFAF6",
    newsletterHeadline: "Reiseideen, Tierwissen und Familientipps.",
    newsletterSub: "Einmal woechentlich Inspiration und Kostenwissen fuer Reisen, Familie und Tiere – kostenlos, jederzeit abbestellbar.",
    footerNote: "Geldhirn Leben ist ein Angebot von Geldhirn – kostenlose Rechner, Ratgeber und Nachrichten rund ums Geld.",
    social: { shareText: "Gelesen auf Geldhirn Leben:" }
  };
});
