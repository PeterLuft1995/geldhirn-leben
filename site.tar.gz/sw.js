"use strict";
/* EchtJetzt – Service Worker (leichtgewichtig)
   App-Shell wird gecacht, Artikel-Seiten netzwerkzuerst mit Cache-Fallback,
   externe Requests (z.B. spaeter AdSense) werden nie abgefangen. */
const CACHE_VERSION = "lebensradar-geldhirn-v2-b202611181511";
const APP_SHELL = ["/", "/index.html", "/styles.css", "/app.js", "/brand.config.js", "/network.config.js", "/ads.config.js", "/membership.js", "/analytics.js", "/manifest.json", "/offline.html"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (new URL(req.url).origin !== self.location.origin) return; // externe Requests nie abfangen
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).then((res) => { const copy = res.clone(); caches.open(CACHE_VERSION).then((c) => c.put(req, copy)); return res; })
        .catch(() => caches.match(req).then((res) => res || caches.match("/offline.html")))
    );
    return;
  }
  event.respondWith(
    caches.match(req).then((cached) => {
      const fetchPromise = fetch(req).then((res) => { const copy = res.clone(); caches.open(CACHE_VERSION).then((c) => c.put(req, copy)); return res; }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
