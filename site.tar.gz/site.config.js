"use strict";
/* site.config.js – LebensRadar: Struktur der Website (nur fuer node tools/build.js). */
module.exports = {
  siteType: "lifestyle",
  hasBreakingBar: false,
  nav: [
    { label: "Rechner", external: "https://geldhirn.de" },
    { label: "Reisen", category: "reisen" },
    { label: "Familie", category: "familie" },
    { label: "Tiere", category: "tiere" },
    { label: "Garten", category: "garten" },
    { label: "Freizeit", category: "freizeit" },
    { label: "Kosten", category: "was-kostet" },
    { label: "Ratgeber", category: "ratgeber" },
    { label: "News", category: "news" }
  ],
  categories: [
    { id: "reisen", slug: "reisen", label: "Reisen", description: "Urlaub, Staedtereisen und Reisewissen.", icon: "plane" },
    { id: "familie", slug: "familie", label: "Familie", description: "Familie, Kinder, Alltag, Umzug und Hochzeit.", icon: "people" },
    { id: "tiere", slug: "tiere", label: "Haustiere", description: "Hunde, Katzen, Kleintiere, Fische und ihre echten Kosten.", icon: "paw" },
    { id: "garten", slug: "garten", label: "Garten & Outdoor", description: "Garten, Pool und Outdoor-Leben.", icon: "flower" },
    { id: "freizeit", slug: "freizeit", label: "Freizeit", description: "Hobbys, Gaming, Freizeitparks und Outdoor-Aktivitaeten.", icon: "ticket" },
    { id: "was-kostet", slug: "was-kostet", label: "Was kostet eigentlich...?", description: "Alltagsfragen rund um echte Kosten im Leben.", icon: "coin" },
    { id: "ratgeber", slug: "ratgeber", label: "Ratgeber", description: "Tier- und Familienwissen zum Nachlesen.", icon: "book" },
    { id: "news", slug: "news", label: "News", description: "Aktuelle Reise- und Lifestyle-Themen.", icon: "starburst" }
  ],
  /* Reihenfolge auf ausdrücklichen Wunsch festgelegt: News zuerst, danach
     Reisen, Familie, Garten, Freizeit, Tiere, danach der Rest. */
  homepageSections: [
    { id: "news", title: "Aktuelle Reise- & Lifestyle-News", categories: ["news"], max: 3 },
    { id: "urlaub-reisen", title: "Urlaub & Reisen", categories: ["reisen"], max: 3 },
    { id: "familie-alltag", title: "Familie & Alltag", categories: ["familie"], max: 3 },
    { id: "garten-outdoor", title: "Garten & Outdoor", categories: ["garten"], max: 3 },
    { id: "freizeit", title: "Freizeit", categories: ["freizeit"], max: 3 },
    { id: "haustiere", title: "Haustiere", categories: ["tiere"], max: 4 },
    { id: "was-kostet", title: "Was kostet eigentlich ...?", categories: ["was-kostet"], max: 3 },
    { id: "ratgeber", title: "Beliebte Ratgeber", categories: ["ratgeber"], max: 3 },
    { id: "tierwissen", title: "Tierwissen", categories: ["tiere"], max: 3, mode: "newest" }
  ]
};
